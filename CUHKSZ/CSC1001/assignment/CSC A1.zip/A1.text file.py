# Open the file in write mode
f = open('explanation.txt', 'w')

# Write an introduction
f.write("This document contains explanations for each code example.\n\n")

# Write the explanation for the first code example
f.write("Code Example 1:\n\n")
f.write("This code prompts the user to enter the final account value, annual interest rate, and number of years. "
        "It then converts the annual interest rate from percent to decimal, calculates the initial deposit amount "
        "using a formula, and displays the result rounded to 13 decimal places.\n\n")

# Write the explanation for the second code example
f.write("Code Example 2:\n\n")
f.write("This code prompts the user to input an integer and stores it in the variable 'num'. It then converts the "
        "'num' string into a list of individual digits and iterates through each digit to print it on separate lines.\n\n")

# Write the explanation for the third code example
f.write("Code Example 3:\n\n")
f.write("This code prompts the user to input a number 'm' and initializes a variable 'n' to 0. It uses a while loop to "
        "increment 'n' until its square is greater than or equal to 'm'. It then prints the value of 'n' to the console.\n\n")

# Write the explanation for the fourth code example
f.write("Code Example 4:\n\n")
f.write("This code defines a function 'print_table' that takes an integer 'N' as input. It first prints a table header "
        "with left alignment. It then checks if 'N' is a positive integer and returns an error message if it's not. "
        "It iterates through each row from 1 to 'N' and calculates the value of 'm^(m+1)'. It prints the values of "
        "'m', 'm+1', and 'm^(m+1)' with left alignment. It then prompts the user to enter the number 'N', calls the "
        "'print_table' function with 'N' as input, and prints the table.\n\n")

# Write the explanation for the fifth code example
f.write("Code Example 5:\n\n")
f.write("This code defines a function 'is_prime' that takes an integer 'num' as input and returns True if it's a prime "
        "number and False otherwise. It then prompts the user to enter a positive integer 'N' and repeatedly validates "
        "the input until it's a positive integer. It iterates through each integer from 2 to 'N'-1, checks if it's a "
        "prime number using the 'is_prime' function, and adds it to a list if it's a prime. It prints the list of primes "
        "formatted with 8 numbers per line.\n\n")

# Write the explanation for the sixth code example
f.write("Code Example 6:\n\n")
f.write("This code imports the math module and defines a dictionary 'trig_functions' that maps the names of "
        "trigonometric functions to their corresponding functions in the math module. It prompts the user to enter a "
        "trigonometric function (sin, cos, or tan), the lower endpoint a, the upper endpoint b, and the number of "
        "sub-intervals n. It checks the user input for each parameter for validity. It calculates the width of each "
        "sub-interval, initializes the sum of function values, and iterates over each sub-interval to calculate the sum "
        "of function values. It calculates the numerical integration using equation (1) and prints the result.\n\n")

# Write a conclusion
f.write("This concludes the explanations for each code example.")

# Close the file
f.close()
