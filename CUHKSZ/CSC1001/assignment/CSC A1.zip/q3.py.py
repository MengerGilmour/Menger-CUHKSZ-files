m = int(input("Enter a number (m): ")) # Prompt the user to input a number and store it in 'm'

n = 0 # Initialize the variable 'n' as 0

while n**2 <= m: # Use a while loop to increment 'n' until its square is greater than or equal to 'm'
    n += 1

# Print the result to the console
print(f"The smallest integer (n) whose square is greater than {m} is: {n}")
