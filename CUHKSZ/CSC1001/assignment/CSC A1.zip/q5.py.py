def is_prime(num): # Define a function to check if a number is prime
    if num <= 1:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True

valid_input = False

while not valid_input: # Use a loop to ensure the user enters a positive integer N
    try:
        N = int(input("Enter an integer N: ")) # Prompt the user to enter an integer N
        if N > 0: # Check if N is a positive integer
            valid_input = True
        else:
            print("Invalid input. Please enter a positive integer.")
    except ValueError:
        print("Invalid input. Please enter an integer.")

count = 0
prime_numbers = []

for i in range(2, N): # Iterate from 2 to N-1 and add prime numbers to the list
    if is_prime(i):
        prime_numbers.append(i)
        count += 1
        if count % 8 == 0: # Print 8 prime numbers per line
            print(*prime_numbers)
            prime_numbers = []

if prime_numbers: # Print any remaining prime numbers that didn't fill the last line
    print(*prime_numbers)
