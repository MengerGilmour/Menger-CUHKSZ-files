import math

# Define the trigonometric functions
trig_functions = {
    'sin': math.sin,
    'cos': math.cos,
    'tan': math.tan
}

# Prompt the user to enter the trigonometric function
valid_function = False
while not valid_function:
    function = input("Enter the trigonometric function (sin, cos, or tan): ")
    if function in trig_functions:
        valid_function = True
    else:
        print("Invalid function. Please enter sin, cos, or tan.")

# Prompt the user to enter the interval endpoints
valid_input = False
while not valid_input:
    try:
        a = float(input("Enter the lower endpoint a: "))
        b = float(input("Enter the upper endpoint b: "))
        if a < b:
            valid_input = True
        else:
            print("Invalid input. b must be greater than a.")
    except ValueError:
        print("Invalid input. Please enter a floating-point number.")

# Prompt the user to enter the number of sub-intervals
valid_input = False
while not valid_input:
    try:
        n = int(input("Enter the number of sub-intervals n: "))
        if n > 0:
            valid_input = True
        else:
            print("Invalid input. Please enter a positive integer.")
    except ValueError:
        print("Invalid input. Please enter an integer.")

# Calculate the width of each sub-interval
width = (b - a) / n

# Initialize the sum of function values
sum_values = 0

# Iterate over each sub-interval and calculate the sum of function values
for i in range(1, n+1):
    x = a + (i - 0.5) * width
    sum_values += trig_functions[function](x)

# Calculate the numerical integration using equation (1)
result = width * sum_values

# Print the result
print("The numerical integration of", function, "over [", a, ",", b, "] is approximately", result)
