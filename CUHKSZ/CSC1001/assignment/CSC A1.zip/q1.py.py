# Prompt the user to enter the final account value, annual interest rate, and number of years
final_value = float(input("Enter the final account value: "))
interest_rate = float(input("Enter the annual interest rate in percent: "))
years = int(input("Enter the number of years: "))

interest_rate_decimal = interest_rate / 100 # Convert the annual interest rate from percent to decimal

initial_deposit = final_value / (1 + interest_rate_decimal) ** years # Calculate the initial deposit amount using the formula

# Display the initial deposit amount, rounded to 13 decimal places, because the result given in the example preserves 13 decimal places
print(f"The initial deposit amount is: {initial_deposit:.13f}")
