def print_table(N):
    print("{:<5s}{:<5s}{:<9s}".format("m", "m+1", "m^(m+1)")) # Print the table header with left alignment

    if N <= 0 or not isinstance(N, int): # Check if N is a positive integer
        print("Invalid input. Please enter a positive integer.")
        return

    for m in range(1, N + 1): # Iterate through each row
        result = m ** (m + 1) # Calculate the value of m^(m+1)
        print("{:<5d}{:<5d}{:<9d}".format(m, m + 1, result)) # Print the values of m, m+1, and m^(m+1) with left alignment

N = int(input("Please enter the number N: ")) # Get the user input for the number N

# Call the function to print the table
print_table(N)
