num = input("Enter an integer: ") # Prompt the user to input an integer and store it in 'num'

digits = list(num) # Convert the 'num' string into a list of individual digits and store it in 'digits'

# Iterate through each digit in the 'digits' list and print it to the console
for digit in digits:
    print(digit)  # Display each digit on a separate line
