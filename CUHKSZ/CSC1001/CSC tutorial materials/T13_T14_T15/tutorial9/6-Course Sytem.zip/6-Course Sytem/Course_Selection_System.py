from System import System

system=System()
system.readStudentDict('student.txt')
system.readStaffDict('staff.txt')
system.show()
system.generateFile()
