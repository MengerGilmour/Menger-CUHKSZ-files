#Given a file "idlist.txt" with student id numbers of many students,
#add "@link.cuhk.edu.cn" after them to get a list of email addresses
#in a file "emailist.txt", output the number of students on the shell.

position=0    # 初始化元素在字符串中的位置为0
email=""      # 初始化电子邮件地址字符串为空
list=[]       # 初始化一个空列表，用于存储所有的电子邮件地址

# 当邮件地址不等于"@link.cuhk.edu.cn"时，继续循环
while email!="@link.cuhk.edu.cn":
    # 打开名为'idlist.txt'的文件进行读取
    with open('idlist.txt','rt') as f:
        # 从文件中读取从position到position + 9的字符，即每个学生的id，并赋值给studentid
        studentid=f.read()[position:(position+9)]
        # 将读取到的学生id和"@link.cuhk.edu.cn"拼接成完整的电子邮件地址
        email=studentid+"@link.cuhk.edu.cn"
        # 将生成的电子邮件地址添加到列表中
        list.append(email)
        # 将位置指针向后移动10位，为读取下一个学生id做准备
        position+=10

# 打开名为'emaillist.txt'的文件进行写入
with open('emaillist.txt','wt') as f:
    amount=0      # 初始化学生数量为0
    # 从列表中获取第一个电子邮件地址
    email=list[amount]

    # 当邮件地址不等于"@link.cuhk.edu.cn"时，继续循环
    while email!="@link.cuhk.edu.cn":
        # 将邮件地址写入到文件中
        f.write(email)
        # 在邮件地址后面添加一个换行符
        f.write('\n')
        # 学生数量加1
        amount+=1
        # 从列表中获取下一个电子邮件地址
        email=list[amount]

# 打印学生总数
print(amount)
