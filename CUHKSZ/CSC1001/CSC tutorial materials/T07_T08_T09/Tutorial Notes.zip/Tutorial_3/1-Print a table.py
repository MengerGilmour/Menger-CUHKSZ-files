##To print a table
##Use formatted output of print function
print('%-8s%-8s%-8s'%('a','b','a**b'))
print('%-8d%-8d%-8d'%(1,2,1**2))
print('%-8d%-8d%-8d'%(2,3,2**3))
print('%-8d%-8d%-8d'%(3,4,3**4))
print('%-8d%-8d%-8d'%(4,5,4**5))
print('%-8d%-8d%-8d'%(5,6,5**6))

##Tips:Use "Alt+#" to add comments and use "Alt+$" to delete comments
      
